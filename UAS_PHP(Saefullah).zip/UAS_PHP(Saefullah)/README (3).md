# Web penjualan Sepatu bola
web ini adalah  penyedia layanan jual beli barang yang dikembangkan untuk penyedia layanan jual beli,fungsi utama aplikasi ini memberikan penggguna akses untuk mendapatkan barang yang sesuai dengan harga nya

## Features
- Manajemen user pengguna
- mendapatkan barang yang sesuai 
- jaminan harga termurah

## Requitments
-Xampp <=8.1.17

## Teknologi
Dalam pembuatan aplikasi ini meliputi
-[Visual studio code](https://code.visualstudio.com/download#)-untuk editing perintah
-[Xampp](https;//www.apachefrien.org/download succes.html) - Sebagai web serve
-[html] - Bahasa pemprograman
-[css] - berupa Bahasa desain

## Installation
Install Xampp
Pindahkan folder proyek ke dalam
.....
C://Xampp/htdocs/[Folder Project]

## Stucture Folder
UAS_PHP
 ┣ css
 ┃ ┣ login.css
 ┃ ┣ profil.css
 ┃ ┗ style.css
 ┣ gambar
 ┃ ┣ gambar1.jpg
 ┃ ┣ gambar2.jpeg
 ┃ ┣ gambar3.jpg
 ┃ ┣ gambar4.jpg
 ┃ ┣ gambar5.png
 ┃ ┣ gambar6.jpg
 ┃ ┣ gambar7.jpg
 ┃ ┣ gambar8.jpg
 ┃ ┣ promo1.jpg
 ┃ ┣ promo2.jpg
 ┃ ┣ promo3.jpg
 ┃ ┗ promo4.jpg
 ┣ index.html
 ┣ login.html
 ┗ profile.html
## Credit
-[IG](https://www.instagram.com/mang_epul12/) Saefullah
-[FB](https://web.facebook.com/saefullah.la.9) Saefullah